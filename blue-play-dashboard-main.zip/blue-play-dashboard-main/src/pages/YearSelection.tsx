import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Gamepad2, TrendingUp } from "lucide-react";

const years = [2020, 2021, 2022, 2023, 2024];

const YearSelection = () => {
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const navigate = useNavigate();

  const handleShowHighlights = () => {
    if (selectedYear) {
      navigate(`/highlights?year=${selectedYear}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12 space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary shadow-[0_0_30px_hsl(var(--ps-blue-glow)/0.5)] mb-4">
            <Gamepad2 className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-primary to-primary-light bg-clip-text text-transparent">
            Your Gaming Journey
          </h1>
          <p className="text-muted-foreground text-lg">Select a year to view your highlights</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {years.map((year) => (
            <Card
              key={year}
              onClick={() => setSelectedYear(year)}
              className={`cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-[0_8px_30px_hsl(var(--primary)/0.3)] ${
                selectedYear === year
                  ? "border-primary border-2 shadow-[0_0_30px_hsl(var(--ps-blue-glow)/0.4)] bg-primary/5"
                  : "border-border/50 hover:border-primary/50"
              }`}
            >
              <CardHeader>
                <CardTitle className="text-3xl font-bold">{year}</CardTitle>
                <CardDescription>Gaming Year</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <TrendingUp className="w-4 h-4" />
                  <span>View statistics & highlights</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex justify-center">
          <Button
            onClick={handleShowHighlights}
            disabled={!selectedYear}
            size="lg"
            className="bg-primary hover:bg-primary-light shadow-[0_4px_20px_hsl(var(--primary)/0.3)] hover:shadow-[0_4px_30px_hsl(var(--primary)/0.5)] transition-all duration-300 text-lg px-8 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Show Highlights
          </Button>
        </div>
      </div>
    </div>
  );
};

export default YearSelection;
