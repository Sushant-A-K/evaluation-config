import { useSearchParams } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { Trophy, Clock, Gamepad2, Target } from "lucide-react";

const playtimeData = [
  { month: "Jan", hours: 45 },
  { month: "Feb", hours: 52 },
  { month: "Mar", hours: 68 },
  { month: "Apr", hours: 41 },
  { month: "May", hours: 55 },
  { month: "Jun", hours: 72 },
  { month: "Jul", hours: 88 },
  { month: "Aug", hours: 65 },
  { month: "Sep", hours: 58 },
  { month: "Oct", hours: 70 },
  { month: "Nov", hours: 82 },
  { month: "Dec", hours: 95 },
];

const gameDistribution = [
  { name: "Action", value: 35, color: "hsl(217, 100%, 45%)" },
  { name: "RPG", value: 25, color: "hsl(217, 100%, 35%)" },
  { name: "Sports", value: 20, color: "hsl(217, 100%, 55%)" },
  { name: "Adventure", value: 20, color: "hsl(217, 100%, 65%)" },
];

const achievementProgress = [
  { month: "Jan", count: 12 },
  { month: "Feb", count: 18 },
  { month: "Mar", count: 25 },
  { month: "Apr", count: 32 },
  { month: "May", count: 38 },
  { month: "Jun", count: 45 },
  { month: "Jul", count: 52 },
  { month: "Aug", count: 58 },
  { month: "Sep", count: 64 },
  { month: "Oct", count: 72 },
  { month: "Nov", count: 78 },
  { month: "Dec", count: 85 },
];

const Highlights = () => {
  const [searchParams] = useSearchParams();
  const year = searchParams.get("year") || "2024";

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary shadow-[0_0_30px_hsl(var(--ps-blue-glow)/0.5)] mb-4">
            <Trophy className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-primary to-primary-light bg-clip-text text-transparent">
            {year} Gaming Wrapped
          </h1>
          <p className="text-muted-foreground text-lg">Your year in gaming, visualized</p>
        </div>

        {/* Video Section */}
        <Card className="overflow-hidden border-border/50 shadow-[0_8px_30px_rgb(0,0,0,0.12)]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gamepad2 className="w-5 h-5 text-primary" />
              Your Highlights Reel
            </CardTitle>
            <CardDescription>Best moments from your gaming year</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-gradient-to-br from-primary/10 to-primary-light/10 rounded-lg flex items-center justify-center border border-primary/20">
              <div className="text-center space-y-2">
                <Gamepad2 className="w-16 h-16 mx-auto text-primary opacity-50" />
                <p className="text-muted-foreground">Video Player Placeholder</p>
                <p className="text-sm text-muted-foreground/70">Your gaming highlights would play here</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-border/50 shadow-[0_4px_20px_hsl(var(--primary)/0.1)] hover:shadow-[0_4px_30px_hsl(var(--primary)/0.2)] transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Hours</CardTitle>
              <Clock className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">791</div>
              <p className="text-xs text-muted-foreground">+23% from last year</p>
            </CardContent>
          </Card>

          <Card className="border-border/50 shadow-[0_4px_20px_hsl(var(--primary)/0.1)] hover:shadow-[0_4px_30px_hsl(var(--primary)/0.2)] transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Achievements</CardTitle>
              <Trophy className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">85</div>
              <p className="text-xs text-muted-foreground">Trophies unlocked</p>
            </CardContent>
          </Card>

          <Card className="border-border/50 shadow-[0_4px_20px_hsl(var(--primary)/0.1)] hover:shadow-[0_4px_30px_hsl(var(--primary)/0.2)] transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Games Played</CardTitle>
              <Gamepad2 className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">42</div>
              <p className="text-xs text-muted-foreground">Different titles</p>
            </CardContent>
          </Card>

          <Card className="border-border/50 shadow-[0_4px_20px_hsl(var(--primary)/0.1)] hover:shadow-[0_4px_30px_hsl(var(--primary)/0.2)] transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
              <Target className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">67%</div>
              <p className="text-xs text-muted-foreground">Games completed</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-border/50 shadow-[0_8px_30px_rgb(0,0,0,0.12)]">
            <CardHeader>
              <CardTitle>Monthly Playtime</CardTitle>
              <CardDescription>Hours played throughout the year</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={playtimeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px"
                    }}
                  />
                  <Bar dataKey="hours" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-border/50 shadow-[0_8px_30px_rgb(0,0,0,0.12)]">
            <CardHeader>
              <CardTitle>Game Genre Distribution</CardTitle>
              <CardDescription>Your favorite game types</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={gameDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {gameDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px"
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-border/50 shadow-[0_8px_30px_rgb(0,0,0,0.12)] lg:col-span-2">
            <CardHeader>
              <CardTitle>Achievement Progress</CardTitle>
              <CardDescription>Cumulative trophies earned throughout the year</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={achievementProgress}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px"
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="count" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={3}
                    dot={{ fill: "hsl(var(--primary))", r: 5 }}
                    activeDot={{ r: 7 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Highlights;
