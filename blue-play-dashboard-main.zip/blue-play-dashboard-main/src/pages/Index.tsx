import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Gamepad2, TrendingUp, Trophy, Sparkles } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background">
      <div className="absolute top-6 right-6">
        <ThemeToggle />
      </div>
      <div className="container mx-auto px-6 py-20">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-primary shadow-[0_0_40px_hsl(var(--ps-blue-glow)/0.6)] mb-8 animate-pulse">
            <Gamepad2 className="w-10 h-10 text-primary-foreground" />
          </div>
          
          <h1 className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-primary via-primary-light to-primary bg-clip-text text-transparent leading-tight">
            PlayStation Wrapped
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto">
            Discover your gaming journey. Relive your greatest moments. See how you played this year.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 max-w-3xl mx-auto">
            <div className="p-6 rounded-2xl bg-card border border-border/50 shadow-lg hover:shadow-[0_4px_30px_hsl(var(--primary)/0.2)] transition-all duration-300">
              <Trophy className="w-8 h-8 text-primary mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Your Achievements</h3>
              <p className="text-sm text-muted-foreground">Track all your trophies and milestones</p>
            </div>
            
            <div className="p-6 rounded-2xl bg-card border border-border/50 shadow-lg hover:shadow-[0_4px_30px_hsl(var(--primary)/0.2)] transition-all duration-300">
              <TrendingUp className="w-8 h-8 text-primary mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Gaming Stats</h3>
              <p className="text-sm text-muted-foreground">Detailed analytics of your playtime</p>
            </div>
            
            <div className="p-6 rounded-2xl bg-card border border-border/50 shadow-lg hover:shadow-[0_4px_30px_hsl(var(--primary)/0.2)] transition-all duration-300">
              <Sparkles className="w-8 h-8 text-primary mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Highlight Reel</h3>
              <p className="text-sm text-muted-foreground">Relive your best gaming moments</p>
            </div>
          </div>

          <div className="pt-8">
            <Button
              onClick={() => navigate("/login")}
              size="lg"
              className="bg-primary hover:bg-primary-light shadow-[0_4px_20px_hsl(var(--primary)/0.4)] hover:shadow-[0_8px_40px_hsl(var(--primary)/0.6)] transition-all duration-300 text-lg px-12 py-6"
            >
              Get Started
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
